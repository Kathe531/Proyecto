from django.db import models

# Create your models here.


class Citas(models.Model):
    codigo = models.CharField(primary_key=True, max_length=6)
    nombre = models.CharField(max_length=50)
    telefono = models.CharField(max_length=12)
    correo = models.CharField(max_length=20)
    fecha = models.DateField(max_length=12)
    hora=models.TimeField(max_length=12)
    precio=models.IntegerField(max_length=12)

    def __str__(self):
        texto = "{0} ({1})"
        return texto.format(self.nombre)
    
class roles(models.Model):
    id=models.AutoField(primary_key=True, max_length=5)
    rol=models.CharField(max_length=50)

    
class Usuarios(models.Model):
    
    documento = models.IntegerField(primary_key = True)
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    contraseña =  models.CharField(max_length=12)
    idRol = models.ForeignKey(roles, on_delete=models.CASCADE)

    
    def __str__(self):
        return f"{self.documento} {self.contraseña}"




    

