from django.contrib import admin
from .models import Citas

admin.site.register(Citas)
