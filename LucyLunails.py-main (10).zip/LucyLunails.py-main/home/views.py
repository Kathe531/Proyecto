from django.shortcuts import render, HttpResponse, redirect
from datetime import datetime
from django.contrib import messages
from django.db.models import Sum
from .models import *
from django.core.mail import send_mail
import smtplib
from django.conf import settings


# Create your views here.

def enviar_correo_respuesta(correo, asunto, mensaje):
    try:
        send_mail(asunto, mensaje, 'saravalentinaabril13@gmail.com', [correo])
        print(f'Correo enviado a {correo}con éxito.')
    except Exception as e:
        print(f'Error al enviar el correo: {str(e)}')

def enviar_correo(request, correo, correo_mani ):
    if request.method == "POST":
        citas = Citas.objects.all()
        correo_usuario = correo
        correo_mani = 'saravalentinaabril13@gmail.com'
        
        asunto = "Confirmación de cita"
        mensaje = "Su cita ha sido agendada correctamente."
        asunto_mani = "Nueva cita"
        mensaje_mani= "Tienes una nueva cita agendada."
        try:
            enviar_correo_respuesta(correo_usuario, asunto, mensaje)
            enviar_correo_respuesta(correo_mani, asunto_mani, mensaje_mani)
            return redirect('citas') 
        except Exception as e:
            print(f'Error al enviar el correo: {str(e)}')

    return render(request, 'citas.html', {"citas": Citas.objects.all()})


from django.db.models import Sum

def dashboard(request):
    citas = Citas.objects.all().order_by('fecha')
    total_ingresos = Citas.objects.aggregate(Sum('precio'))['precio__sum'] or 0
    
    if request.method == 'POST':
        cita_id = request.POST.get('cita_id')  
        precio = request.POST.get('precio') 
        
        cita = Citas.objects.get(pk=cita_id) 

        
        cita.precio = precio
        cita.save()
        
       
        total_ingresos = Citas.objects.aggregate(Sum('precio'))['precio__sum'] or 0
        
        messages.success(request, 'Los datos de la cita se actualizaron correctamente.')
        return redirect('dashboard') 
    
    citas_atendidas = citas.filter(precio__gt=0).count()
    total_citas = citas.count()
    citas_pendientes = citas.filter(precio=0).count()
    
    return render(request, 'home/dashboard.html', {'citas': citas, 'total_ingresos': total_ingresos, 'citas_atendidas': citas_atendidas, 'citas_pendientes': citas_pendientes})


def inicio(request):
    return render(request, "home/bienvenida.html")

def dashCliente(request):
    return render(request, "home/cliente.html")

def dashManicurista(request):
    return render(request, "home/manicurista.html")


def registrarUsuarios(request):
    if request.method=="POST":
    
        documento=request.POST['txtDocumento']
        nombre=request.POST['txtNombre']
        apellido=request.POST['txtApellido']
        correo=request.POST['txtCorreo']
        contraseña=request.POST['txtContraseña']
        confirmar_contraseña = request.POST['txtConfirmarContraseña']
        idRol = roles.objects.get(id=2)

        if len(contraseña) < 8:
            mensaje = "La contraseña debe tener al menos 8 caracteres."
            return HttpResponse(mensaje)

        if Usuarios.objects.filter(documento=documento).exists():
            mensaje = "El Documento {} ya está en uso. Por favor, ingrese un Documento diferente.".format(documento)
            return HttpResponse(mensaje)
        
        if contraseña != confirmar_contraseña:
            mensaje = "La contraseña y su confirmación no coinciden."
            return HttpResponse(mensaje)

        usuario=Usuarios.objects.create(

        documento=documento, nombre=nombre, apellido=apellido, correo=correo, contraseña=contraseña, idRol=idRol)
        usuario.save()

        messages.success(request, 'Usuario registrado correctamente.')
        return redirect("login_form")
    
    return redirect("login_form")



def inicioSesion(request):
     if request.method == 'POST':
        documento = request.POST.get('usuario')
        contraseña = request.POST.get('contrasena')
        user = Usuarios.objects.filter(documento=documento, contraseña=contraseña).first()
     
        if user is not None:
            if user.idRol.id == 1:
                return redirect ('dashboard')
            elif user.idRol.id == 2:
                return render (request,'home/principal.html')
            else:
                return render(request, 'error.html')
        else:
            messages.error(request, 'Credenciales inválidas')
            return redirect('login_form')  # Redirige de nuevo al formulario de inicio de sesión en caso de credenciales inválidas
     return redirect('login_form')



def citasView(request):
    citaslistados = Citas.objects.all()
    return render (request, 'home/gestionCitas.html', {"citas": citaslistados})

def registrarCitas(request):
    if request.method == 'POST':
        codigo = request.POST['txtCodigo']
        nombre = request.POST['txtNombre']
        telefono = request.POST['numTelefono']
        correo = request.POST['txtCorreo']
        fecha = request.POST['txtFecha']
        hora = request.POST['txtHora']
        precio = request.POST['txtPrecio']

        
        if Citas.objects.filter(codigo=codigo).exists():
            mensaje = "El código {} ya está en uso. Por favor, ingrese un código diferente.".format(codigo)
            return HttpResponse(mensaje)

       
        fecha_cita = datetime.strptime(fecha, '%Y-%m-%d')
        if fecha_cita < datetime.today():
            mensaje = "No se pueden agendar citas en fechas pasadas. Por favor, seleccione una fecha válida."
            return HttpResponse(mensaje)

        
        cita = Citas.objects.create(
            codigo=codigo, nombre=nombre, telefono=telefono, correo=correo, fecha=fecha, hora=hora, precio=precio)
        enviar_correo(request, correo, correo_mani='saravalentinaabril13@gmail.com')

        messages.success(request, 'La cita se agendó correctamente.')

        return redirect('citas')
    else:
        
        pass




def edicionCitas(request, codigo):
    citas=Citas.objects.get(codigo=codigo)
    return render(request, "home/edicionCitas.html", {"citas": citas})


def editarCitas(request, codigo):
    citas = Citas.objects.get(codigo=codigo)
    if request.method == 'POST':
        nombre = request.POST['txtNombre']
        telefono = request.POST['numTelefono']
        fecha=request.POST['txtFecha']
        hora =request.POST['txtHora']
        precio =request.POST['txtPrecio']
        
        citas.nombre = nombre
        citas.telefono = telefono
        citas.fecha = fecha 
        citas.hora = hora
        citas.precio = precio

        citas.save()

        # Recalcular el total de ingresos después de la actualización
        total_ingresos = Citas.objects.aggregate(Sum('precio'))['precio__sum'] or 0
        
        messages.success(request, 'Los datos de la cita se actualizaron correctamente.')
        return redirect('dashboard') 
    
    citas_atendidas = citas.filter(estado='Atendida').count()
    citas_pendientes = citas.count() - citas_atendidas
    
    return render(request, 'home/dashboard.html', {'citas': citas, 'total_ingresos': total_ingresos, 'citas_atendidas': citas_atendidas, 'citas_pendientes': citas_pendientes})

    return redirect('dashboard')

    return render(request, "edicionCitas", {"citas": citas})



def eliminarCitas(request, codigo):
     citas=Citas.objects.get(codigo=codigo)
     citas.delete()
     
     return redirect('dashboard')


def login_form(request):
    return render(request, "home/login.html")

def cerrar_sesion(request):
    return render (request, "home/cerrar.html" )

def bienvenida_cliente(request):
    return render (request, "home/bienvenida.html")

def principalCli(request):
    return render (request, "home/principal.html")

def registrese(request):
    return render (request, "home/registrarUsuarios.html")






 
     
     
    
