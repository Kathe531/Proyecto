from django.urls import path
from .views import *

urlpatterns = [
    path('', inicio, name="inicio"),
    path('citas/', citasView, name='citas'),
    path('registrarCitas/', registrarCitas),
    path('edicionCitas/<codigo>', edicionCitas, name="edicionCitas"),
    path('editarCitas/<codigo>/', editarCitas),
    path('eliminarCitas/<codigo>/', eliminarCitas),
    path('registrarUsuarios/', registrarUsuarios,name='registrarUsuarios'),
    path('inicioSesion/', inicioSesion, name='inicioSesion'),
    path('dashboard/', dashboard, name='dashboard'),
    path('dashManicurista/', dashManicurista, name='dashManicurista'),
    path('dashCliente/', dashCliente, name='dashCliente'),
    path('login_form/', login_form, name="login_form"),
    path('cerrar_sesion/', cerrar_sesion, name="cerrar_sesion"),
    path('bienvenida/', bienvenida_cliente, name="bienvenida"),
    path('principal/', principalCli, name='principal'),
    path('registrese/', registrese, name='registrese'),
    


]
